package com.example.wanchengdemo.service;

import com.baomidou.mybatisplus.extension.service.IService;
import com.example.wanchengdemo.entity.Segment;

public interface SegmentService extends IService<Segment> {
}
