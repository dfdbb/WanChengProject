package com.example.wanchengdemo.entity;


public class Section {

  private long sid;
  private String sname;
  private String stesting;
  private String scons;
  private long spid;


  public long getSid() {
    return sid;
  }

  public void setSid(long sid) {
    this.sid = sid;
  }


  public String getSname() {
    return sname;
  }

  public void setSname(String sname) {
    this.sname = sname;
  }


  public String getStesting() {
    return stesting;
  }

  public void setStesting(String stesting) {
    this.stesting = stesting;
  }


  public String getScons() {
    return scons;
  }

  public void setScons(String scons) {
    this.scons = scons;
  }


  public long getSpid() {
    return spid;
  }

  public void setSpid(long spid) {
    this.spid = spid;
  }

}
