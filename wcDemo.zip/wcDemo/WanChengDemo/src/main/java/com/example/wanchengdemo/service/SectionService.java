package com.example.wanchengdemo.service;

import com.baomidou.mybatisplus.extension.service.IService;
import com.example.wanchengdemo.entity.Section;

public interface SectionService extends IService<Section> {
}
