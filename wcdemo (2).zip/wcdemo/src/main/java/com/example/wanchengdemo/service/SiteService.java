package com.example.wanchengdemo.service;

import com.baomidou.mybatisplus.extension.service.IService;
import com.example.wanchengdemo.entity.Site;

public interface SiteService extends IService<Site> {
}
