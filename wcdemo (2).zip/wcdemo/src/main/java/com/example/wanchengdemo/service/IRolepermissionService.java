package com.example.wanchengdemo.service;

import com.baomidou.mybatisplus.extension.service.IService;
import com.example.wanchengdemo.domain.Rolepermission;

public interface IRolepermissionService extends IService<Rolepermission> {
}
