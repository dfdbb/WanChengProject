package com.example.wanchengdemo.service;


import com.baomidou.mybatisplus.extension.service.IService;
import com.example.wanchengdemo.domain.Role;

public interface IRoleService extends IService<Role> {
}
