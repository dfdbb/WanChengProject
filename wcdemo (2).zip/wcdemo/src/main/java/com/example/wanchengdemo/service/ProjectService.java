package com.example.wanchengdemo.service;

import com.baomidou.mybatisplus.extension.service.IService;
import com.example.wanchengdemo.entity.Project;


public interface ProjectService extends IService<Project> {
}
