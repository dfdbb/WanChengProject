package com.example.wanchengdemo.service;


import com.baomidou.mybatisplus.extension.service.IService;
import com.example.wanchengdemo.domain.Permission;

public interface IPermissionService extends IService<Permission> {
}
