package com.example.wanchengdemo.service;

import com.baomidou.mybatisplus.extension.service.IService;

public interface SegmentService extends IService<Segment> {
}
