package com.example.wanchengdemo.entity;


public class Segment {

  private long segid;
  private String segrange;
  private String segdesign;
  private String segdate;
  private long segsid;


  public long getSegid() {
    return segid;
  }

  public void setSegid(long segid) {
    this.segid = segid;
  }


  public String getSegrange() {
    return segrange;
  }

  public void setSegrange(String segrange) {
    this.segrange = segrange;
  }


  public String getSegdesign() {
    return segdesign;
  }

  public void setSegdesign(String segdesign) {
    this.segdesign = segdesign;
  }


  public String getSegdate() {
    return segdate;
  }

  public void setSegdate(String segdate) {
    this.segdate = segdate;
  }


  public long getSegsid() {
    return segsid;
  }

  public void setSegsid(long segsid) {
    this.segsid = segsid;
  }

}
