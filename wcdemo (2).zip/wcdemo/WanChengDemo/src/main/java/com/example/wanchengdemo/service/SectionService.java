package com.example.wanchengdemo.service;

import com.baomidou.mybatisplus.extension.service.IService;

public interface SectionService extends IService<Section> {
}
