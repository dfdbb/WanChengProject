package com.example.wanchengdemo.service;

import com.baomidou.mybatisplus.extension.service.IService;

public interface SiteService extends IService<Site> {
}
