package com.example.wanchengdemo.entity;


public class Segment {

  private String segid;
  private String segrange;
  private String segdesign;
  private String segdate;
  private String segsid;
  private String roadway;
  private String roadhandle;
  private java.sql.Timestamp createtime;
  private String modifiedby;
  private java.sql.Timestamp updatetime;


  public String getSegid() {
    return segid;
  }

  public void setSegid(String segid) {
    this.segid = segid;
  }


  public String getSegrange() {
    return segrange;
  }

  public void setSegrange(String segrange) {
    this.segrange = segrange;
  }


  public String getSegdesign() {
    return segdesign;
  }

  public void setSegdesign(String segdesign) {
    this.segdesign = segdesign;
  }


  public String getSegdate() {
    return segdate;
  }

  public void setSegdate(String segdate) {
    this.segdate = segdate;
  }


  public String getSegsid() {
    return segsid;
  }

  public void setSegsid(String segsid) {
    this.segsid = segsid;
  }


  public String getRoadway() {
    return roadway;
  }

  public void setRoadway(String roadway) {
    this.roadway = roadway;
  }


  public String getRoadhandle() {
    return roadhandle;
  }

  public void setRoadhandle(String roadhandle) {
    this.roadhandle = roadhandle;
  }


  public java.sql.Timestamp getCreatetime() {
    return createtime;
  }

  public void setCreatetime(java.sql.Timestamp createtime) {
    this.createtime = createtime;
  }


  public String getModifiedby() {
    return modifiedby;
  }

  public void setModifiedby(String modifiedby) {
    this.modifiedby = modifiedby;
  }


  public java.sql.Timestamp getUpdatetime() {
    return updatetime;
  }

  public void setUpdatetime(java.sql.Timestamp updatetime) {
    this.updatetime = updatetime;
  }

}
