package com.example.wanchengdemo.entity;


public class Section {

  private String sid;
  private String sname;
  private String stesting;
  private String scons;
  private String spid;
  private java.sql.Timestamp createtime;
  private String modifiedby;
  private java.sql.Timestamp updatetime;


  public String getSid() {
    return sid;
  }

  public void setSid(String sid) {
    this.sid = sid;
  }


  public String getSname() {
    return sname;
  }

  public void setSname(String sname) {
    this.sname = sname;
  }


  public String getStesting() {
    return stesting;
  }

  public void setStesting(String stesting) {
    this.stesting = stesting;
  }


  public String getScons() {
    return scons;
  }

  public void setScons(String scons) {
    this.scons = scons;
  }


  public String getSpid() {
    return spid;
  }

  public void setSpid(String spid) {
    this.spid = spid;
  }


  public java.sql.Timestamp getCreatetime() {
    return createtime;
  }

  public void setCreatetime(java.sql.Timestamp createtime) {
    this.createtime = createtime;
  }


  public String getModifiedby() {
    return modifiedby;
  }

  public void setModifiedby(String modifiedby) {
    this.modifiedby = modifiedby;
  }


  public java.sql.Timestamp getUpdatetime() {
    return updatetime;
  }

  public void setUpdatetime(java.sql.Timestamp updatetime) {
    this.updatetime = updatetime;
  }

}
