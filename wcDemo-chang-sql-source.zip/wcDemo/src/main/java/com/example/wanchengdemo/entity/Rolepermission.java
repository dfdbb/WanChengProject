package com.example.wanchengdemo.entity;


public class Rolepermission {

  private String roleid;
  private String rolename;
  private String permissionid;
  private String permissioname;
  private java.sql.Timestamp createtime;
  private String modifiedby;
  private java.sql.Timestamp updatetime;


  public String getRoleid() {
    return roleid;
  }

  public void setRoleid(String roleid) {
    this.roleid = roleid;
  }


  public String getRolename() {
    return rolename;
  }

  public void setRolename(String rolename) {
    this.rolename = rolename;
  }


  public String getPermissionid() {
    return permissionid;
  }

  public void setPermissionid(String permissionid) {
    this.permissionid = permissionid;
  }


  public String getPermissioname() {
    return permissioname;
  }

  public void setPermissioname(String permissioname) {
    this.permissioname = permissioname;
  }


  public java.sql.Timestamp getCreatetime() {
    return createtime;
  }

  public void setCreatetime(java.sql.Timestamp createtime) {
    this.createtime = createtime;
  }


  public String getModifiedby() {
    return modifiedby;
  }

  public void setModifiedby(String modifiedby) {
    this.modifiedby = modifiedby;
  }


  public java.sql.Timestamp getUpdatetime() {
    return updatetime;
  }

  public void setUpdatetime(java.sql.Timestamp updatetime) {
    this.updatetime = updatetime;
  }

}
